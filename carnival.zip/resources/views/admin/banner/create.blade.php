@extends('admin.layout.app')
@section('page-title', 'Create Banner Sliders')

@section('section')
<section class="content">
    <div class="container-fluid">
        <div class="row">
            
        </div>
    </div>
</section>
@endsection
