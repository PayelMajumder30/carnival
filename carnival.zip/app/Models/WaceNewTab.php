<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WaceNewTab extends Model
{
    use HasFactory;
    protected $table = "wace_new_tab";
}
